
var krms_config ={	
	'ApiUrl' : "http://justyugen.com/mobileapp/api",
	'DialogDefaultTitle' : "JY Mobile",
	'pushNotificationSenderid' : "586483766015",
	'facebookAppId' : "YOUR_FACEBOOK_APP_ID",
	'APIHasKey' : "AIzaSyA7Ks_q3Spk8qsQ_as-CI151epHjlmUxeo"
};